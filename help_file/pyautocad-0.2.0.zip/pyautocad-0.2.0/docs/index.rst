.. pyautocad documentation master file, created by
   sphinx-quickstart on Sun Mar 25 09:29:19 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyautocad's documentation!
=====================================

pyautocad_ - library aimed to simplify writing ActiveX_ Automation_ scripts for AutoCAD_ with Python

Contents:
=========

.. toctree::
    :maxdepth: 2

    gettingstarted
    usage
    api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _pyautocad: http://pypi.python.org/pypi/pyautocad/
.. _ActiveX: http://wikipedia.org/wiki/ActiveX
.. _Automation: http://en.wikipedia.org/wiki/OLE_Automation
.. _AutoCAD: http://wikipedia.org/wiki/AutoCAD


